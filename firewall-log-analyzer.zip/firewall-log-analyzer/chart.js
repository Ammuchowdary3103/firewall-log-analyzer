document.getElementById("fileInput").addEventListener("change", function(event) {
    const file = event.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = function(e) {
        const content = e.target.result;
        processCSV(content);
    };
    reader.readAsText(file);
});

function processCSV(csvContent) {
    const lines = csvContent.trim().split("\n").slice(1); // Ignore header
    let allowCount = 0, blockCount = 0;

    lines.forEach(line => {
        const columns = line.split(",");
        if (columns.length > 1) {
            const status = columns[1].trim().toLowerCase();
            if (status === "allow") allowCount++;
            else if (status === "block") blockCount++;
        }
    });

    const total = allowCount + blockCount;
    if (total === 0) {
        document.getElementById("statusMessage").innerText = "No valid data found in the file.";
        return;
    }

    const allowPercent = (allowCount / total) * 100;
    const blockPercent = (blockCount / total) * 100;

    document.getElementById("statusMessage").innerText = "Log Data Processed Successfully!";
    renderPieChart(allowPercent, blockPercent);
}

function renderPieChart(allowPercent, blockPercent) {
    const ctx = document.getElementById("pieChart").getContext("2d");

    if (window.myPieChart) window.myPieChart.destroy(); // Destroy previous chart

    window.myPieChart = new Chart(ctx, {
        type: "pie",
        data: {
            labels: ["Allowed", "Blocked"],
            datasets: [{
                data: [allowPercent, blockPercent],
                backgroundColor: ["#2ecc71", "#e74c3c"], // Green & Red
                borderColor: ["#27ae60", "#c0392b"], // Darker shades for border
                borderWidth: 2,
                hoverOffset: 6
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: "top",
                    labels: {
                        color: "white",
                        font: {
                            size: 14
                        }
                    }
                },
                tooltip: {
                    callbacks: {
                        label: function(tooltipItem) {
                            return `${tooltipItem.label}: ${tooltipItem.raw.toFixed(2)}%`;
                        }
                    }
                }
            }
        }
    });
}
