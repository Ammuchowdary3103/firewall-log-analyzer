document.getElementById('fileInput').addEventListener('change', handleFileUpload);

function handleFileUpload(event) {
    const file = event.target.files[0];

    if (!file) {
        console.error("No file selected!");
        return;
    }

    const reader = new FileReader();
    reader.onload = function (e) {
        const fileContent = e.target.result;
        const logLines = fileContent.trim().split("\n");

        let allowedCount = 0;
        let blockedCount = 0;

        logLines.forEach(line => {
            const parts = line.split(",");
            if (parts.length < 2) return;

            const status = parts[1].trim().toLowerCase(); // Normalize status
            if (status === "allow" || status === "allowed") {
                allowedCount++;
            } else if (status === "block" || status === "blocked") {
                blockedCount++;
            }
        });

        const total = allowedCount + blockedCount;

        if (total === 0) {
            console.warn("No valid logs found.");
            document.getElementById("logStatus").innerText = "No valid log data found!";
            return;
        }

        const allowedPercentage = ((allowedCount / total) * 100).toFixed(2);
        const blockedPercentage = ((blockedCount / total) * 100).toFixed(2);

        console.log(`Allowed: ${allowedPercentage}%`, `Blocked: ${blockedPercentage}%`);

        updatePieChart(allowedCount, blockedCount, allowedPercentage, blockedPercentage);
    };

    reader.readAsText(file);
}

function updatePieChart(allowedCount, blockedCount, allowedPercentage, blockedPercentage) {
    const ctx = document.getElementById('myChart').getContext('2d');

    if (window.myChart) {
        window.myChart.destroy();
    }

    window.myChart = new Chart(ctx, {
        type: 'pie',
        data: {
            labels: [`Allowed (${allowedPercentage}%)`, `Blocked (${blockedPercentage}%)`],
            datasets: [{
                data: [allowedCount, blockedCount],
                backgroundColor: ['#4CAF50', '#F44336'],
                borderColor: ['#ffffff', '#ffffff'],
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    labels: {
                        color: "#fff",
                        font: { size: 14 }
                    }
                },
                tooltip: {
                    callbacks: {
                        label: function (tooltipItem) {
                            const value = tooltipItem.raw;
                            const total = allowedCount + blockedCount;
                            const percentage = ((value / total) * 100).toFixed(2);
                            return `${tooltipItem.label}: ${percentage}% (${value} logs)`;
                        }
                    }
                }
            }
        }
    });

    document.getElementById("logStatus").innerText = "Log Data Processed Successfully!";
}
